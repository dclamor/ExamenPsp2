//package u3.TCP.PruebaObserver;

import java.util.List;

public interface Subject {
    void subscribe(Observer observer);
}
