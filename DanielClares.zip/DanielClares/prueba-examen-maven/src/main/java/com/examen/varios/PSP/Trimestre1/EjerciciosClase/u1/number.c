#include <stdio.h>

int main(void) {
    int num = 43;
    printf("Esto es un núemro: %d\n", num);
    scanf("%d", &num);
    printf("El número nuevo es: %d\n", num);
    return 0;
}

//tarea: programa que le pida a un usuario la suma de dos números y devuelva el resultado
