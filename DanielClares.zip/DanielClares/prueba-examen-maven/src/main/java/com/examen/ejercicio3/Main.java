package com.examen.ejercicio3;

import java.net.ServerSocket;
import java.net.Socket;

public class Main {

    private static final int RESOURCE_POSITION = 1;

    public static void main(String[] args) {

        try (ServerSocket server = new ServerSocket(Integer.parseInt(args[0]))) {
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    server.close();
                    System.out.println("Servidor cerrado.");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }));// este bloque garantiza que se libere la conexion al cerrar el programa
            while (true) {
                Socket connCliente = server.accept();
                Thread clientThread = new Thread(new ClientHandler(connCliente));
                clientThread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String extraeRecurso(String header) {
        return header.split(" ")[RESOURCE_POSITION];
    }

    public static String generaPagina(PrimosHTTP primosHTTP) {
        StringBuilder builder = new StringBuilder();
        builder.append("<ul>\n");

        primosHTTP.addListener(primo -> {
            builder.append(String.format("<li> %d </li>\n", primo));
            System.out.println(primo);
        });

        primosHTTP.generarPrimos();

        builder.append("</ul>\n");

        return builder.toString();
    }
}
