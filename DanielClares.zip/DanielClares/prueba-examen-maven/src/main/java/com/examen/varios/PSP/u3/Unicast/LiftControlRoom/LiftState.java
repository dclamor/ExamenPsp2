package LiftControlRoom;

public enum LiftState {
    STATIONARY, GOING_UP, GOING_DOWN;
}
