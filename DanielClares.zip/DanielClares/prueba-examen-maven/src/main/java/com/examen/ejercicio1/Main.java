package com.examen.ejercicio1;

public class Main {

    public static void main(String[] args) {

        Receptor receptor = new Receptor(Integer.parseInt(args[0]));
        Enviador enviador = new Enviador(Integer.parseInt(args[1]));
        // Receptor receptor = new Receptor(1234);
        // Enviador enviador = new Enviador(4321);
        receptor.addListener(enviador);

        receptor.escuchar();
    }

}
// java -classpath
// /home/dani/Desktop/DanielClares/prueba-examen-maven/src/main/java
// com.examen.ejercicio1.Main 4454 4453
// nc-luk 4453
// sudo echo 3 8 f|nc -u 192.168.56.101 4454
