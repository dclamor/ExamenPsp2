//package u3.TCP.PruebaObserver;

public interface Observer {
    void update();
}
