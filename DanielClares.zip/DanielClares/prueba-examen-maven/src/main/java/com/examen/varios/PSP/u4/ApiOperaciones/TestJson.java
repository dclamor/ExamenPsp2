package u4.ApiOperaciones;

public class TestJson {
    public static void main(String[] args) {
        String a = "a", b = "b", c = "c", d = "d";

        System.out.println("{\n\t\"operando 1\": \"" + a + "\",\n\t\"operando 2\": \"" + b
                + "\",\n\t\"operacion\": \"" + c + "\",\n\t\"resultado\": " + d + "\"\n}");
    }
}
