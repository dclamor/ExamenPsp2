package com.examen.ejercicio3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ClientHandler implements Runnable {

    private Socket connCliente;

    public ClientHandler(Socket connCliente) {
        this.connCliente = connCliente;
    }

    @Override
    public void run() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(connCliente.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(connCliente.getOutputStream()));

            String peticion = reader.readLine();

            int inicial;
            int cantidad;
            try {
                String[] argumentosRecurso = Main.extraeRecurso(peticion).split("/");
                inicial = Integer.parseInt(argumentosRecurso[1]);
                cantidad = Integer.parseInt(argumentosRecurso[2]);
            } catch (Exception e) {
                return;
            }

            PrimosHTTP primosHTTP = new PrimosHTTP(connCliente, inicial, cantidad);
            Logger logger = new Logger();
            primosHTTP.addListener(logger);

            String html = Main.generaPagina(primosHTTP);
            writer.write("HTTP/1.1 200 OK\n");
            writer.write("\n");
            writer.write(html);
            writer.flush();
            connCliente.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
