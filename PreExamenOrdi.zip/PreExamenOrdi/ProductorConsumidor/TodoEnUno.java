package ProductorConsumidor;

import java.util.LinkedList;

public class TodoEnUno {
    private static final LinkedList<Integer> buffer = new LinkedList<>();
    private static final int BUFFER_SIZE = 5;

    public static void main(String[] args) {
        Thread producer = new Thread(() -> {
            while (true) {
                produce();
            }
        });

        Thread consumer = new Thread(() -> {
            while (true) {
                consume();
            }
        });

        producer.start();
        consumer.start();
    }

    private static void produce() {
        synchronized (buffer) {
            while (buffer.size() == BUFFER_SIZE) {
                try {
                    buffer.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            int item = (int) (Math.random() * 100);
            buffer.add(item);
            System.out.println("Produced: " + item);
            buffer.notifyAll();
        }
    }

    private static void consume() {
        synchronized (buffer) {
            while (buffer.isEmpty()) {
                try {
                    buffer.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            int item = buffer.removeFirst();
            System.out.println("Consumed: " + item);
            buffer.notifyAll();
        }
    }

    public boolean esPrimo(int numero) {
        // Los números menores o iguales a 1 no son primos
        if (numero <= 1) {
            return false;
        }

        // Verificamos si el número es divisible por algún número entre 2 y su raíz
        // cuadrada
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                // Si el número es divisible, no es primo
                return false;
            }
        }
        // Si no se encontró ningún divisor, el número es primo
        return true;
    }
}
