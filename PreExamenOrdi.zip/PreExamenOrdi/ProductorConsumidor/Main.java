package ProductorConsumidor;

public class Main {
    public static void main(String[] args) {

        Consumible consumible = new Consumible();
        Consumidor consumidor = new Consumidor(consumible);
        Productor productor = new Productor(consumible);
        productor.start();
        consumidor.start();

    }

    public boolean esPrimo(int numero) {
        // Los números menores o iguales a 1 no son primos
        if (numero <= 1) {
            return false;
        }

        // Verificamos si el número es divisible por algún número entre 2 y su raíz
        // cuadrada
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                // Si el número es divisible, no es primo
                return false;
            }
        }
        // Si no se encontró ningún divisor, el número es primo
        return true;
    }

}
