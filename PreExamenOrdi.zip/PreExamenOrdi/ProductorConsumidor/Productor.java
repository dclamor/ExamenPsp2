package ProductorConsumidor;

public class Productor extends Thread {

    private Consumible consumible;
    private final int MAX_ESPERA = 1000;
    private final int MIN_ESPERA = 500;

    public Productor(Consumible consumible) {
        this.consumible = consumible;
    }

    @Override
    public void run() {
        while (true) {

            try {
                Thread.sleep((int) (Math.random() * (MAX_ESPERA - MIN_ESPERA) + MIN_ESPERA));
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            consumible.producir();

        }

    }
}
