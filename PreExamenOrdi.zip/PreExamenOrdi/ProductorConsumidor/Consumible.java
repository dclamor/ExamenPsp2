package ProductorConsumidor;

public class Consumible {
    private final int MAX = 10;
    private final int MIN = 0;
    private int num = 0;

    public Consumible() {
        num = 0;
    }

    public synchronized void producir() {
        while (num == MAX) {
            try {

                System.out.println("Productor esperando\n");
                wait();

            } catch (InterruptedException e) {

                e.printStackTrace();
            }

        }
        num++;

        System.out.printf("Se ha producido, valor actual %d \n", num);
        notifyAll();

    }

    public synchronized void consumir() {
        while (num == MIN) {
            try {

                System.out.println("Consumidor esperando\n");
                wait();

            } catch (InterruptedException e) {

                e.printStackTrace();
            }

        }
        num--;
        System.out.printf("Se ha consumido, valor actual %d \n", num);
        notifyAll();

    }
}
