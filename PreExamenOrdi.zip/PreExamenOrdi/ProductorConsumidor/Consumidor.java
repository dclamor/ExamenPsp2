package ProductorConsumidor;

public class Consumidor extends Thread {

    private final int MAX_ESPERA = 1000;
    private final int MIN_ESPERA = 500;
    private Consumible consumible;

    public Consumidor(Consumible consumible) {
        this.consumible = consumible;
    }

    @Override
    public void run() {

        try {
            Thread.sleep(2000);// esperar a que se produzca algo
        } catch (InterruptedException e) {

            e.printStackTrace();
        }
        while (true) {
            try {
                Thread.sleep((int) (Math.random() * (MAX_ESPERA - MIN_ESPERA) + MIN_ESPERA));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            consumible.consumir();

        }

    }

}
