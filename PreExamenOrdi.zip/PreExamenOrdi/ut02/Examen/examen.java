package ut02.Examen;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class examen {

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Por favor, ingresa el nombre de usuario como parámetro.");
            return;
        }

        String usuario = args[0];

        try {
            ProcessBuilder processBuilder = new ProcessBuilder("ps", "aux");
            Process proceso = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
            String linea;

            // Leer la cabecera
            if ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }

            // Leer los procesos del usuario con consumo de memoria mayor a 0.0
            while ((linea = reader.readLine()) != null) {
                String[] columnas = linea.split("\\s+"); // Dividir la línea en columnas por espacios \\s+ = regex para
                                                         // un conjunto de uno o más espacios
                // si quieres separar por más cosas seria "[\\s,./]+"
                // \\s representa cualquier espacio en blanco (incluyendo espacios,
                // tabulaciones, retornos de carro, etc.).
                // , representa una coma.
                // . necesita ser escapado con \ porque en una expresión regular . representa
                // cualquier carácter, pero aquí queremos que represente un punto literal.
                // / también necesita ser escapado con \ ya que se usa como un delimitador en
                // expresiones regulares.Si quisieras separar por / y . seria [/\//.]

                // El + al final indica que la división se realizará para una o más ocurrencias
                // de cualquiera de los delimitadores especificados. Con esto, linea se dividirá
                // en un array de strings utilizando todos los delimitadores especificados.
                // para unirlos de vuelta seria String nuevo = String.join(" ", columnas);" " es
                // como lu unira se puede sustituir por , o lo que sea

                if (columnas.length > 10 && columnas[0].equals(usuario) && Double.parseDouble(columnas[5]) > 0.0) {
                    System.out.println(linea);
                }
            }

            proceso.waitFor(); // Esperar a que el proceso termine
            proceso.destroy(); // Destruir el proceso

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
