package ut02.Elefantes;

public class CancionInfantil implements Runnable {

  public enum Animal {
    ELEFANTE, OSO, PATO;
  }

  Animal animal;
  int maxRepeticiones;

  public CancionInfantil(Animal animal, int maxRepeticiones) {
    this.animal = animal;
    this.maxRepeticiones = maxRepeticiones;
  }

  @Override
  public void run() {
    for (int i = 1; i <= maxRepeticiones; i++) {
      if (i == 1) {
        System.out.println(i + " " + animal.toString().toLowerCase() + " se balanceaba sobre la tela de una araña");
        try {
          Thread.sleep(1000);
        } catch (Exception e) {
        }
        System.out.println("Como veía que no se caía, fue a llamar otro " + animal.toString().toLowerCase());
        try {
          Thread.sleep(1000);
        } catch (Exception e) {
        }
      } else {
        System.out.println(i + " " + animal.toString().toLowerCase() + "s se balanceaban sobre la tela de una araña");
        try {
          Thread.sleep(1000);
        } catch (Exception e) {
        }
        System.out.println("Como veían que no se caían, fueron a llamar otro " + animal.toString().toLowerCase());
        try {
          Thread.sleep(1000);
        } catch (Exception e) {
        }
      }
    }
  }
}