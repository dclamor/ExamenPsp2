package ut02.Carrera;

public class Corredor implements Runnable {
    public static final long TIEMPO_DESCANSO = 500;
    public static final double MAX_INTERVALO_KM = 10;

    int kmTotales;
    int kmRecorridos;
    int dorsal;
    Object salida;
    static int listo = 0;

    public Corredor(int kmTotales, int dorsal, Object salida) {
        this.kmTotales = kmTotales;
        this.dorsal = dorsal;
        kmRecorridos = 0;
        this.salida = salida;
    }

    @Override
    public void run() {

        synchronized (salida) {
            try {
                listo++;
                salida.wait();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        System.out.printf("Soy el dorsal %d he iniciado la carrera\n", dorsal);
        while (kmRecorridos < kmTotales) {
            try {
                Thread.sleep((long) ((Math.random() * TIEMPO_DESCANSO) + TIEMPO_DESCANSO));
            } catch (InterruptedException e) {

                e.printStackTrace();
            }
            kmRecorridos += Math.random() * MAX_INTERVALO_KM;
            System.out.printf("Soy el dorsal %d estoy descansando he recorrido %d/%d\n", dorsal, kmRecorridos,
                    kmTotales);
        }
        System.out.printf("Soy el dorsal %d he terminado la carrera\n", dorsal);
    }

}