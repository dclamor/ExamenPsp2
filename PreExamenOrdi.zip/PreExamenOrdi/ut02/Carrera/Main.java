package ut02.Carrera;

public class Main {
    private static final int TOTAL_CARRERA = 100;
    private static final int NUMERO_CORREDORES = 10;

    public static void main(String[] args) {
        Object salida = new Object();

        Thread arrayCorredores[] = new Thread[NUMERO_CORREDORES];
        boolean todosListos = false;

        for (int i = 0; i < NUMERO_CORREDORES; i++) {
            arrayCorredores[i] = new Thread(new Corredor(TOTAL_CARRERA, (int) (Math.random() * 5000), salida));
        }

        System.out.println("La carrera va a empezar!");

        for (Thread corredor : arrayCorredores) {
            corredor.start();

        }
        // synchronized (salida) {
        // salida.notifyAll();
        // }

        while (!todosListos) {
            if (Corredor.listo == NUMERO_CORREDORES) {
                todosListos = true;
            } else {

                synchronized (salida) {
                    salida.notifyAll();
                }
            }
        }

        for (Thread corredor : arrayCorredores) {
            try {
                corredor.join();
            } catch (InterruptedException e) {

                e.printStackTrace();
            }
        }

        System.out.println("La carrera terminó");

    }
}
