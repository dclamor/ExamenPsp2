import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class Colecciones {

    public class EjemploArrayList {

        // Declarar ArrayList
        ArrayList<String> arrayList = new ArrayList<>();

        // Agregar elementos
        public void cosas() {// tienen que ir dentro de un metodo
            arrayList.add("Uno");
            arrayList.add("Dos");
            arrayList.add("Tres");

            // Obtener tamaño
            int tamaño = arrayList.size();
            System.out.println("Tamaño del ArrayList: " + tamaño);

            // Obtener un elemento por índice
            String elemento = arrayList.get(1);
            System.out.println("Elemento en el índice 1: " + elemento);

            // Verificar si contiene un elemento
            boolean contiene = arrayList.contains("Cuatro");
            System.out.println("ArrayList contiene 'Cuatro': " + contiene);

            // Eliminar el primer elemento
            arrayList.remove(0);

            // Eliminar el último elemento
            arrayList.remove(arrayList.size() - 1);
        }

    }

    public class EjemploLinkedList {

        // Declarar LinkedList
        LinkedList<Integer> linkedList = new LinkedList<>();

        public void cosas() {
            // Agregar elementos
            linkedList.add(10);
            linkedList.add(20);
            linkedList.add(30);

            // Obtener tamaño
            int tamaño = linkedList.size();
            System.out.println("Tamaño del LinkedList: " + tamaño);

            // Obtener primer elemento
            int primerElemento = linkedList.getFirst();
            System.out.println("Primer elemento: " + primerElemento);

            // Obtener último elemento
            int ultimoElemento = linkedList.getLast();
            System.out.println("Último elemento: " + ultimoElemento);
            linkedList.removeFirst();

            // Eliminar el último elemento
            linkedList.removeLast();
            // Valor a eliminar
            int valorAEliminar = 3;

            // Verificar si el valor a eliminar está presente en la LinkedList
            if (linkedList.contains(valorAEliminar)) {
                // Eliminar el valor específico de la LinkedList
                linkedList.remove(Integer.valueOf(valorAEliminar));
                System.out.println("LinkedList después de eliminar " + valorAEliminar + ": " + linkedList);
            } else {
                System.out.println("El valor " + valorAEliminar + " no está presente en la LinkedList.");
            }
        }
    }

    public class EjemploHashMap {

        // Declarar HashMap
        HashMap<String, Integer> hashMap = new HashMap<>();

        public void cosas() {
            // Agregar pares clave-valor
            hashMap.put("A", 1);
            hashMap.put("B", 2);
            hashMap.put("C", 3);

            // Obtener tamaño
            int tamaño = hashMap.size();
            System.out.println("Tamaño del HashMap: " + tamaño);

            // Obtener valor asociado a una clave
            int valor = hashMap.get("B");
            System.out.println("Valor asociado a la clave 'B': " + valor);

            // Verificar si contiene una clave
            boolean contiene = hashMap.containsKey("D");
            System.out.println("HashMap contiene la clave 'D': " + contiene);
            Integer valorB = hashMap.get("B");
            if (valorB != null) {
                System.out.println("Valor asociado a la clave 'B' (mayúscula): " + valorB);
            } else {
                System.out.println("No se encontró un valor para la clave 'B' (mayúscula).");
            }
        }

    }
}
