package CosasComplejas;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class combinator {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Uso: java CombinationsGenerator <n>");
            return;
        }

        int numChildren = Integer.parseInt(args[0]);

        if (numChildren <= 0) {
            System.out.println("El número de hijos debe ser positivo.");
            return;
        }

        for (int i = 0; i < numChildren; i++) {
            int childIndex = i + 1;
            new Thread(() -> generateCombinations(childIndex)).start();
        }
        System.out.println("sos");
    }

    private static void generateCombinations(int childIndex) {
        int n = childIndex;
        char[] chars = new char[26 * 2]; // 'a' to 'Z'
        for (int i = 0; i < 26; i++) {
            chars[i] = (char) ('a' + i);
            chars[i + 26] = (char) ('A' + i);
        }

        int totalCombinations = (int) Math.pow(52, n);

        for (int i = 0; i < totalCombinations; i++) {
            StringBuilder combination = new StringBuilder();
            int temp = i;
            for (int j = 0; j < n; j++) { // la primera vez que entra tiene el valor de la segunda letra
                combination.append(chars[temp % 52]);
                temp /= 52;// al dividirla entre 52 como es un int y no guarda el resto te va dando los
                           // valores de la primera letra 55/52 = 1 ->'b'
            }
            writeToFile("combinaciones" + n + "_" + childIndex + ".txt", combination.reverse().toString());
        }
    }

    private static void writeToFile(String filename, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(content);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
