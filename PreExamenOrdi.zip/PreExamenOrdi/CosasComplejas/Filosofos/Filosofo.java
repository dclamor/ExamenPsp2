package CosasComplejas.Filosofos;

public class Filosofo extends Thread {

    private final Object tenedorIzquierdo;
    private final Object tenedorDerecho;

    public Filosofo(Object tenedorIzquierdo, Object tenedorDerecho) {
        this.tenedorIzquierdo = tenedorIzquierdo;
        this.tenedorDerecho = tenedorDerecho;
    }

    private void hacerAccion(String accion) throws InterruptedException {
        System.out.println(Thread.currentThread().getName() + " " + accion);
        Thread.sleep(((int) (Math.random() * 100)));
    }

    @Override
    public void run() {
        try {
            while (true) {
                // System.nanoTime() devuelve un long con el tiempo en nanosegundos que tarda en
                // hacer algo no hace falta es para ver la salida
                hacerAccion(System.nanoTime() + ": Filosofando");
                synchronized (tenedorIzquierdo) {
                    hacerAccion(System.nanoTime() + ": Cojo el tenedor izquierdo");
                    synchronized (tenedorDerecho) {
                        hacerAccion(System.nanoTime() + ": Cojo el tenedor derecho y como");
                        hacerAccion(System.nanoTime() + ": Devuelvo el tenedor derecho");
                    }
                    hacerAccion(System.nanoTime() + ": Devuelvo el tenedor izquierdo. Vuelvo a filosofar");
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            // ^ esto interrumpe el thread si algo falla porque se petaba si no,
            // currentThread
            // currentThread sirve para referirse al thread que se está ejecutando
        }
    }
}
