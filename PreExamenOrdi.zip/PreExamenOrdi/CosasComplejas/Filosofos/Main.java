package CosasComplejas.Filosofos;

public class Main {
    private static final int NUM_FILOSOFOS = 5;
    private static final Filosofo[] filosofos = new Filosofo[NUM_FILOSOFOS];
    private static final Object[] tenedores = new Object[NUM_FILOSOFOS];

    public static void main(String[] args) {
        for (int i = 0; i < NUM_FILOSOFOS; i++) {
            tenedores[i] = new Object();
        }

        for (int i = 0; i < NUM_FILOSOFOS; i++) {
            Object tenedorIzquierdo, tenedorDerecho;
            // Asigna tenedores en diferentes órdenes dependiendo del número del filósofo
            // para que no se bloqueen a la larga
            if (i % 2 == 0) {
                tenedorIzquierdo = tenedores[i];
                tenedorDerecho = tenedores[(i + 1) % NUM_FILOSOFOS];
            } else {
                tenedorIzquierdo = tenedores[(i + 1) % NUM_FILOSOFOS];
                tenedorDerecho = tenedores[i];
            }

            filosofos[i] = new Filosofo(tenedorIzquierdo, tenedorDerecho);
            Thread t = new Thread(filosofos[i], "Filosofo " + (i + 1));
            t.start();
        }
    }

}
