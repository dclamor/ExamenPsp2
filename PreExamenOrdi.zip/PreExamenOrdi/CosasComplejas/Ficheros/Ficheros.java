package CosasComplejas.Ficheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Ficheros {
    private static final String FILENAME = "data.txt";
    private static final Object lock = new Object();
    private static final String FIN = "Line 8";

    public static void main(String[] args) {
        Thread writerThread = new Thread(() -> {
            synchronized (lock) {
                // el true es para que haga append
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILENAME, true))) {
                    for (int i = 1; i <= 10; i++) {
                        writer.write("Line " + i);
                        writer.newLine();
                        Thread.sleep(500); // Simulate writing process
                    }
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread readerThread = new Thread(() -> {
            try {
                Thread.sleep(500); // Wait for some lines to be written
                synchronized (lock) {
                    System.out.println("Reading data from file:");
                    try (BufferedReader reader = new BufferedReader(new FileReader(FILENAME))) {
                        String line;
                        while ((line = reader.readLine()) != null && !line.equals(FIN)) {

                            System.out.println(line);
                        }
                    }
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        });

        writerThread.start();
        readerThread.start();

        try {
            writerThread.join();
            readerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
