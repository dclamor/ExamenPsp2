package CosasComplejas.Ficheros;

import java.io.*;

public class FicherosSimultaneos {
    private static final String FILENAME = "data.txt";
    private static final Object lock = new Object();
    private static final String FIN = "Line 8";
    private static boolean lineaEscrita = false;
    private static boolean readerAcabo = false;

    public static void main(String[] args) {
        Thread writerThread = new Thread(() -> {
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(FILENAME));
                synchronized (lock) {
                    for (int i = 1; i <= 10; i++) {
                        writer.write("Line " + i);
                        writer.newLine();
                        writer.flush();
                        lineaEscrita = true;
                        lock.notify(); // Notifica al lector que hay una línea disponible
                        if (i != 10 && !readerAcabo) // Si no es la última línea, espera a que el lector termine de leer
                            lock.wait();
                    }
                    writer.close();
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        });

        Thread readerThread = new Thread(() -> {
            try {
                Thread.sleep(1000); // Espera a que se escriban algunas líneas
                BufferedReader reader = new BufferedReader(new FileReader(FILENAME));
                synchronized (lock) {
                    System.out.println("Leyendo datos desde el archivo:");
                    String line;
                    while ((line = reader.readLine()) != null && !line.equals(FIN)) {
                        Thread.sleep(200);
                        System.out.println(line);
                        if (!lineaEscrita) {
                            lock.wait(); // Espera a que el escritor termine de escribir la línea
                        }
                        lineaEscrita = false;
                        lock.notify(); // Notifica al escritor que puede escribir la siguiente línea
                        lock.wait();// vuelve a esperar porque si al iterar el bucle le daría null

                    }
                    readerAcabo = true;
                    lock.notify();// importante dar este notify porqie sino el reader se queda esperando
                    reader.close();

                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        });

        writerThread.start();
        readerThread.start();

        try {
            writerThread.join();
            readerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
